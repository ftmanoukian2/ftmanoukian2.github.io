# Este programa verifica si un número ingresado por el usuario es par o impar

numero = int(input("Ingrese un número entero: "))

if numero % 2 == 0:
print(numero, "es un número par")
else:
    print(numero, "es un número impar")
