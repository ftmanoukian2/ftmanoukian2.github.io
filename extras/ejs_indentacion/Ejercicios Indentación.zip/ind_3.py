# Este programa verifica si una palabra ingresada por el usuario es un palíndromo

    def es_palindromo(palabra):
  palabra_invertida = palabra[::-1]
if palabra == palabra_invertida:
   return True
     else:
return False

palabra = input("Ingrese una palabra para verificar si es un palíndromo: ")

 if es_palindromo(palabra):
         print(palabra, "es un palíndromo")
 else:
print(palabra, "no es un palíndromo")
