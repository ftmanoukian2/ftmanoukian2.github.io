# Este programa analiza una palabra ingresada por el usuario e imprime información sobre la misma

def contar_vocales(palabra):
    vocales = 'aeiou'
    cantidad_vocales = 0
    for letra in palabra:
        if letra.lower() in vocales:
            cantidad_vocales += 1
            return cantidad_vocales

    def analizar_palabra(palabra):
        longitud = len(palabra)
        cantidad_vocales = contar_vocales(palabra)
        es_palindromo = palabra == palabra[::-1]
        es_mayuscula = palabra.isupper()

        print("Análisis de la palabra:", palabra)
        print("Longitud:", longitud)
        print("Cantidad de vocales:", cantidad_vocales)
        if es_palindromo:
            print("Es un palíndromo")
        else:
            print("No es un palíndromo")
            if es_mayuscula:
                print("Está escrita completamente en mayúsculas")
            else:
        print("No está escrita completamente en mayúsculas")

        def menu():
            print("Bienvenido al Analizador de Palabras")
    print("1. Analizar una palabra")
    print("2. Salir")
    opcion = input("Ingrese su opción: ")
    return opcion

correr_programa = True
while correr_programa:
        opcion = menu()
        if opcion == '1':
            palabra = input("Ingrese la palabra que desea analizar: ")
            analizar_palabra(palabra)
        elif opcion == '2':
            print("¡Hasta luego!")
            correr_programa = False
        else:
            print("Opción inválida. Por favor, ingrese 1 o 2.")

