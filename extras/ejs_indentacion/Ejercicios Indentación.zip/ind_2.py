# Este programa genera triángulos de asteriscos de altura variable

altura = int(input("Ingrese la altura del triángulo: "))

 for i in range(altura):
        for j in range(i + 1):
    print("*", end=" ")
        print()
