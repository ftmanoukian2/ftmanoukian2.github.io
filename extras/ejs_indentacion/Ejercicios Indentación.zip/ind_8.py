# Este programa convierte una temperatura ingresada por el usuario de Celsius a Fahrenheit

celsius = float(input("Ingrese la temperatura en grados Celsius: "))

fahrenheit = (celsius * 9 / 5) + 32
print("La temperatura en grados Fahrenheit es:", fahrenheit)
