# Este programa genera una secuencia de potencias de 2 hasta un límite ingresado por el usuario

limite = int(input("Ingrese el límite para generar las potencias de 2: "))

potencias = []
    valor = 1
    for i in range(limite):
   potencias.append(valor)
 valor *= 2

print("Las potencias de 2 hasta", limite, "son:", potencias)
