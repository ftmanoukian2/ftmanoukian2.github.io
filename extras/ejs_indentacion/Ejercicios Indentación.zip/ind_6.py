# Este programa busca un elemento ingresado por el usuario en una lista dada y muestra su ubicación

lista = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
elemento_buscado = int(input("Ingrese el elemento que desea buscar: "))

encontrado = False
for indice_busqueda in range(len(lista)):
    if lista[indice_busqueda] == elemento_buscado:
        encontrado = True
indice = indice_busqueda

    if encontrado:
   print("El elemento", elemento_buscado, "fue encontrado en la posición", indice)
 else:
print("El elemento", elemento_buscado, "no fue encontrado en la lista")
