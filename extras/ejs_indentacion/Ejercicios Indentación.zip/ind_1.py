# Este programa calcula el factorial de un número ingresado por el usuario

    def factorial(n):
    if n == 0:
        return 1
        else:
            return n * factorial(n - 1)

numero = int(input("Ingrese un número para calcular su factorial: "))

  print("El factorial de", numero, "es:", factorial(numero))
