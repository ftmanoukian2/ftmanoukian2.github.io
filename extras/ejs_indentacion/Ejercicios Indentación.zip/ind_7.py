# Este programa cuenta la cantidad de números pares e impares en una lista ingresada por el usuario

numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

contador_pares = 0
contador_impares = 0
for num in numeros:
    if num % 2 == 0:
contador_pares += 1
else:
    contador_impares += 1

print("Cantidad de números pares:", contador_pares)
print("Cantidad de números impares:", contador_impares)
