# Este programa calcula el área de un círculo con un radio ingresado por el usuario

 radio = float(input("Ingrese el radio del círculo: "))

area = 3.14159 * radio ** 2
    print("El área del círculo es:", area)
